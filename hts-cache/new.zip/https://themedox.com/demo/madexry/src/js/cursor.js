<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta property="og:image" content="">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
	<title>Page not found &#8211; ThemeDox</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
<link rel="alternate" type="application/rss+xml" title="ThemeDox &raquo; Feed" href="https://themedox.com/index.php/feed/" />
<link rel="alternate" type="application/rss+xml" title="ThemeDox &raquo; Comments Feed" href="https://themedox.com/index.php/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/themedox.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.4"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='dashicons-css' href='https://themedox.com/wp-includes/css/dashicons.min.css?ver=6.5.4' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://themedox.com/wp-includes/css/dist/block-library/style.min.css?ver=6.5.4' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://themedox.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='e-animations-css' href='https://themedox.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.21.8' type='text/css' media='all' />
<link rel='stylesheet' id='tijarah-plugns-css' href='https://themedox.com/wp-content/plugins/tijarah-element/inc/../assets/css/plugins.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='tijarah-plugn-css' href='https://themedox.com/wp-content/plugins/tijarah-element/inc/../assets/css/plugin.css?ver=6.5.4' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='tijarah-fonts-css' href='//fonts.googleapis.com/css?family=Rubik%3A300%2C400%2C500%2C700%2C900%26display%3Dswap&#038;ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='tijarah-plugin-css' href='https://themedox.com/wp-content/themes/tijarah/assets/css/plugin.css?ver=6.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='tijarah-style-css' href='https://themedox.com/wp-content/themes/tijarah/style.css?ver=6.5.4' type='text/css' media='all' />
<style id='tijarah-style-inline-css' type='text/css'>
	
	.preview-btn li a:hover,
	.call-to-action,
	#backtotop i,
	.comment-navigation .nav-links a,
	blockquote:before,
	.mean-container .mean-nav ul li a.mean-expand:hover,
	button, input[type="button"], 
	.widget_price_filter .ui-slider .ui-slider-range,
	.widget_price_filter .ui-slider .ui-slider-handle,
	input[type="reset"], 
	.off-canvas-menu .navigation li>a:hover,
	.off-canvas-menu .navigation .dropdown-btn:hover,
	.off-canvas-menu .navigation li .cart-contents,
	input[type="submit"],
	.tijarah-search-btn,
	.video-item .view-detail,
	.woocommerce-store-notice .woocommerce-store-notice__dismiss-link,
	.widget-product-details .widget-add-to-cart .variations .value .variation-radios [type="radio"]:checked + label:after, 
	.widget-product-details .widget-add-to-cart .variations .value .variation-radios [type="radio"]:not(:checked) + label:after,
	.plyr__control--overlaid,
	.plyr--video .plyr__control.plyr__tab-focus,
	.plyr--video .plyr__control:hover,
	.plyr--video .plyr__control[aria-expanded=true],
	.product-social-share .float,
	.banner2 .banner-cat .cat-count,
	ul.banner-button li:first-child a,
	ul.banner-button li a:hover,
	.tijarah-pricing-table.recommended,
	.tijarah-pricing-table a:hover,
	.wedocs-single-wrap .wedocs-sidebar ul.doc-nav-list > li.current_page_parent > a, .wedocs-single-wrap .wedocs-sidebar ul.doc-nav-list > li.current_page_item > a, .wedocs-single-wrap .wedocs-sidebar ul.doc-nav-list > li.current_page_ancestor > a,
	.primary-menu ul li .children li.current-menu-item>a,
	.primary-menu ul li .sub-menu li.current-menu-item>a,
	.header-btn .sub-menu li.is-active a,
	.download-item-button a:hover,
    .recent-themes-widget,
    .newest-filter ul li.select-cat,
    .download-filter ul li.select-cat,
    .woocommerce .onsale,
    .download-item-overlay ul a:hover,
    .download-item-overlay ul a.active,
	input[type="button"],
	input[type="reset"],
	input[type="submit"],
	.checkout-button,
    .woocommerce-tabs ul.tabs li.active a:after,
    .tagcloud a:hover,
    .tijarah-btn,
    .dokan-btn,
    a.dokan-btn,
    .dokan-btn-theme,
    input[type="submit"].dokan-btn-theme,
	.tijarah-btn.bordered:hover,
    .testimonials-nav .slick-arrow:hover,
    .widget-woocommerce .single_add_to_cart_button,
    .post-navigation .nav-previous a ,
	.post-navigation .nav-next a,
	.blog-btn .btn:hover,
	.mean-container .mean-nav,
	.recent-theme-item .permalink,
	.banner-item-btn a,
	.meta-attributes li span a:hover,
	.theme-item-price span,
	.error-404 a,
	.mini-cart .widget_shopping_cart .woocommerce-mini-cart__buttons a,
	.download-item-image .onsale,
	.theme-item-btn a:hover,
	.theme-banner-btn a,
	.comment-list .comment-reply-link,
	.comment-form input[type=submit],
	.pagination .nav-links .page-numbers.current,
	.pagination .nav-links .page-numbers:hover,
	.breadcrumb-banner,
	.header-btn .children li a:hover,
	.primary-menu ul li .children li a:hover,
	.excerpt-date,	
	.widget-title:after,
	.widget-title:before,
	.primary-menu ul li .sub-menu li a:hover,
	.header-btn .sub-menu li a:hover,
	.photo-product-item .button,
	.tags a:hover,
	.playerContainer .seekBar .outer .inner,
	.playerContainer .volumeControl .outer .inner,
	.excerpt-readmore a {
		background: #FF416C;
		background: -webkit-linear-gradient(to right, #FF416C, #FF4B2B);
		background: linear-gradient(to right, #FF416C, #FF4B2B);
	}

	.mini-cart .cart-contents:hover span,
	ul.banner-button li a,	
	.order-again a,
	.testimonial-content>i,
	.testimonials-nav .slick-arrow,
	.tijarah-btn.bordered,
	.header-btn .my-account-btn,
	.primary-menu ul li.current-menu-item>a,
	.cat-links a,
	.plyr--full-ui input[type=range],
	.tijarah-team-social li a,
	.preview-btn li a,
	.related-post-title a:hover,
	.comment-author-link,
	.entry-meta ul li a:hover,
	.widget-product-details table td span a:hover,
	.woocommerce-message a,
	.woocommerce-info a,
	.footer-widget ul li a:hover,
	.woocommerce-noreviews a,
	.widget li a:hover,
	p.no-comments a,
	.woocommerce-notices-wrapper a,
	.woocommerce table td a,
	.blog-meta span,
	.blog-content h4:hover a,
	.tags-links a,
	.tags a,
	.woocommerce-account .woocommerce-MyAccount-navigation li.is-active a,
	.navbar-logo-text,
	.docs-single h4 a:hover,
	.docs-single ul li a:hover,
	.navbar .menu-item>.active,
	blockquote::before,
	.woocommerce-tabs ul.tabs li.active a,
	.woocommerce-tabs ul.tabs li a:hover,
	.primary-menu ul li>a:hover,
	.the_excerpt .entry-title a:hover{
		color: #FF416C;
	}

	
	.tijarah-btn.bordered,
	ul.banner-button li a,
	.testimonials-nav .slick-arrow,
	.my-account-btn,
	.widget-title,
	.preview-btn li a,
	.woocommerce-info,
    .download-item-overlay ul a:hover,
    .download-item-overlay ul a.active,
	.tijarah-pricing-table a,
	.woocommerce-MyAccount-navigation .is-active a,
	blockquote,
	.testimonials-nav .slick-arrow:hover,
	.loader,
	.uil-ripple-css div,
	.uil-ripple-css div:nth-of-type(1),
	.uil-ripple-css div:nth-of-type(2),
	.related-themes .single-related-theme:hover,
	.theme-author span,
	.tags a,
	.playerContainer,
	.sticky .the_excerpt_content {
		border-color: #FF416C!important;
	}

	
	.navbar-toggler-icon {
	  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='#FF416C' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
	}

	/*----------------------------------------
	IF SCREEN SIZE LESS THAN 769px WIDE
	------------------------------------------*/

	@media screen and (max-width: 768px) {
		.navbar .menu-item>.active {
	 		background: #FF416C;
		}
	}

</style>
<link rel='stylesheet' id='tijarah-woocommerce-style-css' href='https://themedox.com/wp-content/themes/tijarah/assets/css/woocommerce.css?ver=6.5.4' type='text/css' media='all' />
<style id='tijarah-woocommerce-style-inline-css' type='text/css'>
@font-face {
			font-family: "star";
			src: url("https://themedox.com/wp-content/plugins/woocommerce/assets/fonts/star.eot");
			src: url("https://themedox.com/wp-content/plugins/woocommerce/assets/fonts/star.eot?#iefix") format("embedded-opentype"),
				url("https://themedox.com/wp-content/plugins/woocommerce/assets/fonts/star.woff") format("woff"),
				url("https://themedox.com/wp-content/plugins/woocommerce/assets/fonts/star.ttf") format("truetype"),
				url("https://themedox.com/wp-content/plugins/woocommerce/assets/fonts/star.svg#star") format("svg");
			font-weight: normal;
			font-style: normal;
		}
</style>
<link rel='stylesheet' id='dokan-style-css' href='https://themedox.com/wp-content/plugins/dokan-lite/assets/css/style.css?ver=1717661529' type='text/css' media='all' />
<link rel='stylesheet' id='dokan-modal-css' href='https://themedox.com/wp-content/plugins/dokan-lite/assets/vendors/izimodal/iziModal.min.css?ver=1717661529' type='text/css' media='all' />
<link rel='stylesheet' id='dokan-fontawesome-css' href='https://themedox.com/wp-content/plugins/dokan-lite/assets/vendors/font-awesome/css/font-awesome.min.css?ver=3.11.2' type='text/css' media='all' />
<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Rubik:700,normal&#038;display=swap&#038;ver=1703618778" /><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rubik:700,normal&#038;display=swap&#038;ver=1703618778" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rubik:700,normal&#038;display=swap&#038;ver=1703618778" /></noscript><script type="text/javascript" src="https://themedox.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/dokan-lite/assets/vendors/izimodal/iziModal.min.js?ver=3.11.2" id="dokan-modal-js"></script>
<script type="text/javascript" id="dokan-i18n-jed-js-extra">
/* <![CDATA[ */
var dokan = {"ajaxurl":"https:\/\/themedox.com\/wp-admin\/admin-ajax.php","nonce":"b6b92ba2bd","ajax_loader":"https:\/\/themedox.com\/wp-content\/plugins\/dokan-lite\/assets\/images\/ajax-loader.gif","seller":{"available":"Available","notAvailable":"Not Available"},"delete_confirm":"Are you sure?","wrong_message":"Something went wrong. Please try again.","vendor_percentage":"100","commission_type":"percentage","rounding_precision":"6","mon_decimal_point":".","currency_format_num_decimals":"2","currency_format_symbol":"$","currency_format_decimal_sep":".","currency_format_thousand_sep":",","currency_format":"%s%v","round_at_subtotal":"no","product_types":["simple"],"loading_img":"https:\/\/themedox.com\/wp-content\/plugins\/dokan-lite\/assets\/images\/loading.gif","store_product_search_nonce":"55a2f82482","i18n_download_permission":"Are you sure you want to revoke access to this download?","i18n_download_access":"Could not grant access - the user may already have permission for this file or billing email is not set. Ensure the billing email is set, and the order has been saved.","maximum_tags_select_length":"-1","modal_header_color":"#F05025","rest":{"root":"https:\/\/themedox.com\/index.php\/wp-json\/","nonce":"ab6fcdd41b","version":"dokan\/v1"},"api":null,"libs":[],"routeComponents":{"default":null},"routes":[],"urls":{"assetsUrl":"https:\/\/themedox.com\/wp-content\/plugins\/dokan-lite\/assets"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/dokan-lite/assets/vendors/i18n/jed.js?ver=3.11.2" id="dokan-i18n-jed-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/dokan-lite/assets/vendors/sweetalert2/sweetalert2.all.min.js?ver=1717661529" id="dokan-sweetalert2-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-includes/js/dist/vendor/moment.min.js?ver=2.29.4" id="moment-js"></script>
<script type="text/javascript" id="moment-js-after">
/* <![CDATA[ */
moment.updateLocale( 'en_US', {"months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"weekdaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"week":{"dow":1},"longDateFormat":{"LT":"g:i a","LTS":null,"L":null,"LL":"F j, Y","LLL":"F j, Y g:i a","LLLL":null}} );
/* ]]> */
</script>
<script type="text/javascript" id="dokan-util-helper-js-extra">
/* <![CDATA[ */
var dokan_helper = {"i18n_date_format":"F j, Y","i18n_time_format":"g:i a","week_starts_day":"1","reverse_withdrawal":{"enabled":false},"timepicker_locale":{"am":"am","pm":"pm","AM":"AM","PM":"PM","hr":"hr","hrs":"hrs","mins":"mins"},"daterange_picker_local":{"toLabel":"To","firstDay":1,"fromLabel":"From","separator":" - ","weekLabel":"W","applyLabel":"Apply","cancelLabel":"Clear","customRangeLabel":"Custom","daysOfWeek":["Su","Mo","Tu","We","Th","Fr","Sa"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"]},"sweetalert_local":{"cancelButtonText":"Cancel","closeButtonText":"Close","confirmButtonText":"OK","denyButtonText":"No","closeButtonAriaLabel":"Close this dialog"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/dokan-lite/assets/js/helper.js?ver=1717661529" id="dokan-util-helper-js"></script>
<script type="text/javascript" id="tijarah_thumb_product_ajax_script-js-extra">
/* <![CDATA[ */
var tijarah_ajax_thumb_products_obj = {"tijarah_thumb_product_ajax_nonce":"f967ab830c","tijarah_thumb_product_ajax_url":"https:\/\/themedox.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/tijarah-element/inc/ajax-woo-thumb-products/ajax.js" id="tijarah_thumb_product_ajax_script-js"></script>
<script type="text/javascript" id="tijarah_product_ajax_script-js-extra">
/* <![CDATA[ */
var tijarah_ajax_products_obj = {"tijarah_product_ajax_nonce":"9d47572c0f","tijarah_product_ajax_url":"https:\/\/themedox.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/tijarah-element/inc/ajax-woo-products/ajax.js" id="tijarah_product_ajax_script-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.9.2" id="jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/themedox.com\/index.php\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=8.9.2" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.8.9.2" id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=8.9.2" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<link rel="https://api.w.org/" href="https://themedox.com/index.php/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://themedox.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.4" />
<meta name="generator" content="WooCommerce 8.9.2" />
<meta name="generator" content="Redux 4.4.17" />	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.21.8; features: e_optimized_assets_loading, e_optimized_css_loading, e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
<link rel="icon" href="https://themedox.com/wp-content/uploads/2020/04/thumbnail-32x32.png" sizes="32x32" />
<link rel="icon" href="https://themedox.com/wp-content/uploads/2020/04/thumbnail.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://themedox.com/wp-content/uploads/2020/04/thumbnail.png" />
<meta name="msapplication-TileImage" content="https://themedox.com/wp-content/uploads/2020/04/thumbnail.png" />
<style id="tijarah_opt-dynamic-css" title="dynamic-css" class="redux-options-output">h1,h2,h3,h4,h5,h6{font-family:Rubik;font-weight:700;font-style:normal;color:#333;}body,p{font-family:Rubik;line-height:26px;font-weight:normal;font-style:normal;color:#808080;font-size:16px;}.site-header{background-color:#fff;}.breadcrumb-banner h1,.breadcrumbs ul li{color:#FFFFFF;}</style>	
</head>

<body class="error404 wp-custom-logo theme-tijarah woocommerce-no-js woocommerce-active elementor-default elementor-kit-15 dokan-theme-tijarah">
	 	
			<!-- Preloading -->
		<div id="preloader">
		    <div class="spinner">
		        <div class="uil-ripple-css" style="transform:scale(0.29);">
		            <div></div>
		            <div></div>
		        </div>
		    </div>
		</div>
		
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
	<header class="site-header ">
		<div class="container">
	        <div class="row align-items-center">
	            <div class="col-xl-2 col-md-3">
	                <div class="logo">
	                    <a href="https://themedox.com/" class="custom-logo-link" rel="home"><img width="260" height="56" src="https://themedox.com/wp-content/uploads/2020/04/logo.png" class="custom-logo" alt="ThemeDox" decoding="async" /></a>	                </div>
	            </div>
	            <div class="col-xl-8 col-md-9">
	                <div class="primary-menu d-none d-lg-inline-block float-right">
	                    <nav class="desktop-menu">
	                        <ul id="menu-primary" class="menu"><li id="menu-item-1971" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1971"><a href="https://themedox.com/">Home</a></li>
<li id="menu-item-289" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289"><a href="https://themedox.com/index.php/about/">About</a></li>
<li id="menu-item-285" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-285"><a href="https://themedox.com/index.php/shop-2/">Themes</a>
<ul class="sub-menu">
	<li id="menu-item-2447" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2447"><a href="https://themedox.com/index.php/shop-2/">Shop Full Width</a></li>
	<li id="menu-item-2445" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2445"><a href="https://themebing.com/wp/tijarah/shop/?shop_layout=left_sidebar">Shop Left Sidebar</a></li>
	<li id="menu-item-2446" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2446"><a href="https://themebing.com/wp/tijarah/shop/?shop_layout=right_sidebar">Shop Right Sidebar</a></li>
</ul>
</li>
<li id="menu-item-2357" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2357"><a href="https://themedox.com/index.php/services/">Services</a></li>
<li id="menu-item-2381" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2381"><a href="https://themedox.com/index.php/team/">Team</a></li>
<li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="https://themedox.com/index.php/contact/">Contact</a></li>
  <li class="menu-cart">
    <a class="cart-contents menu-item" href="https://themedox.com/index.php/cart/" title="View your shopping cart">
      <span class="cart-contents-count"><i class="fa fa-shopping-cart"></i> 
        0 items      </span>
    </a>

    <div class="mini-cart">
      <div class="widget woocommerce widget_shopping_cart"><div class="widget_shopping_cart_content"></div></div>    </div>
  </li>
  </ul>	                    </nav>	                    
	                </div>
	            </div>
	                        	<div class="col-xl-2 p-0 text-right">
					<div class="header-btn d-none d-xl-block">
						<a class="my-account-btn" href="https://themedox.com/index.php/my-account/">
															<img src="https://themedox.com/wp-content/themes/tijarah/assets/images/user.png" alt="Hello world!">
														My Account						</a>
											</div>
            	</div>
	            	        </div>
	    </div>
	</header><!-- #masthead -->
	<!--Mobile Navigation Toggler-->
	<div class="off-canvas-menu-bar">
		<div class="container">
			<div class="row">
				<div class="col-8 my-auto">
				<a href="https://themedox.com/" class="custom-logo-link" rel="home"><img width="260" height="56" src="https://themedox.com/wp-content/uploads/2020/04/logo.png" class="custom-logo" alt="ThemeDox" decoding="async" /></a>				</div>
				<div class="col-2 my-auto">
				                	<div class="header-btn float-right">
						<a class="my-account-btn" href="https://themedox.com/index.php/my-account/">
															<img src="https://themedox.com/wp-content/themes/tijarah/assets/images/user.png" alt="Hello world!">
													</a>
											</div>
	            				</div>
				<div class="col-2 my-auto">
					<div class="mobile-nav-toggler"><span class="fas fa-bars"></span></div>
				</div>
			</div>
		</div>
	</div>
    <!-- Mobile Menu  -->
    <div class="off-canvas-menu">
        <div class="menu-backdrop"></div>
        <i class="close-btn fa fa-close"></i>
        <nav class="mobile-nav">
        	<div class="text-center pt-3 pb-3">
            <a href="https://themedox.com/" class="custom-logo-link" rel="home"><img width="260" height="56" src="https://themedox.com/wp-content/uploads/2020/04/logo.png" class="custom-logo" alt="ThemeDox" decoding="async" /></a>            </div>

            <ul class="navigation"><!--Keep This Empty / Menu will come through Javascript--></ul>
        </nav>
    </div>

		<!-- START BREADCRUMB AREA -->
	<section class="breadcrumb-banner">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="breadcrumb-title">
						<h1>
						  Page not found						</h1>
						<div class="breadcrumbs">
							<ul class="trail-items" itemscope itemtype="http://schema.org/BreadcrumbList"><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="trail-item trail-begin"> <a href="https://themedox.com/" itemprop="item"><span itemprop="name">Home</span></a> <meta itemprop="position" content="1" /> </li><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="trail-item trail-end"> <span itemprop="name">404 Not Found</span> <meta itemprop="position" content="2" /> </li></ul>						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--END BREADCRUMB AREA-->

<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="error-404">
				<h1 class="page-title">Oops! That page can’t be found.</h1>
				<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
				<a href="https://themedox.com" class="btn">Go to Home</a>
			</div>
		</div>
	</div>
</div>



	<footer id="colophon" class="site-footer">
				<div class="footer-widgets">
			<div class="container">
				<div class="row justify-content-xl-between">
					<div class="col-lg-4">
						<div id="custom_html-1" class="widget_text footer-widget widget_custom_html"><div class="textwidget custom-html-widget"><div class="pr-5">
	<img width="140" src="https://themebing.com/wp/tijarah/wp-content/uploads/2020/04/logo.png" class="img-fluid mb-4" alt="Tijarah">
    <div class="footer-text mb-4">
        <p>Popularised in the with the release of etras sheets containing passages and more rcently with desop publishing software like Maker including.</p>
    </div>
    <div class="footer-social">
        <ul>
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
        </ul>
    </div>
</div></div></div>					</div>
					<div class="col-xl-2 col-lg-4 col-md-3 col-sm-6">
						<div id="nav_menu-1" class="footer-widget widget_nav_menu"><h5 class="widget-title">Products</h5><div class="menu-help-support-container"><ul id="menu-help-support" class="menu"><li id="menu-item-2271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2271"><a href="https://themedox.com/index.php/my-account-2/">My account</a></li>
<li id="menu-item-2273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2273"><a href="https://themedox.com/index.php/about/">About Us</a></li>
<li id="menu-item-2275" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2275"><a href="https://themedox.com/index.php/checkout-2/">Checkout</a></li>
<li id="menu-item-2272" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2272"><a href="https://themedox.com/index.php/contact/">Contact Us</a></li>
<li id="menu-item-2274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2274"><a href="https://themedox.com/index.php/shop-2/">Plugins</a></li>
</ul></div></div>					</div>
					<div class="col-xl-2 col-lg-4 col-md-3 col-sm-6">
						<div id="nav_menu-2" class="footer-widget widget_nav_menu"><h5 class="widget-title">Resources</h5><div class="menu-our-company-container"><ul id="menu-our-company" class="menu"><li id="menu-item-2262" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2262"><a href="https://themedox.com/index.php/about/">About Us</a></li>
<li id="menu-item-2268" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2268"><a href="https://themedox.com/index.php/my-account-2/">My account</a></li>
<li id="menu-item-2270" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2270"><a href="https://themedox.com/index.php/shop-2/">Themes</a></li>
<li id="menu-item-2266" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2266"><a href="https://themedox.com/index.php/contact/">Contact Us</a></li>
<li id="menu-item-2267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2267"><a href="https://themedox.com/index.php/checkout-2/">Checkout</a></li>
</ul></div></div>					</div>
					<div class="col-xl-2 col-lg-4 col-md-3 col-sm-6">
						<div id="nav_menu-3" class="footer-widget widget_nav_menu"><h5 class="widget-title">Company</h5><div class="menu-help-support-container"><ul id="menu-help-support-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2271"><a href="https://themedox.com/index.php/my-account-2/">My account</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2273"><a href="https://themedox.com/index.php/about/">About Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2275"><a href="https://themedox.com/index.php/checkout-2/">Checkout</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2272"><a href="https://themedox.com/index.php/contact/">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2274"><a href="https://themedox.com/index.php/shop-2/">Plugins</a></li>
</ul></div></div>					</div>
					<div class="col-xl-2 col-lg-4 col-md-3 col-sm-6">
						<div id="nav_menu-4" class="footer-widget widget_nav_menu"><h5 class="widget-title">Help and FAQs</h5><div class="menu-our-company-container"><ul id="menu-our-company-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2262"><a href="https://themedox.com/index.php/about/">About Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2268"><a href="https://themedox.com/index.php/my-account-2/">My account</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2270"><a href="https://themedox.com/index.php/shop-2/">Themes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2266"><a href="https://themedox.com/index.php/contact/">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2267"><a href="https://themedox.com/index.php/checkout-2/">Checkout</a></li>
</ul></div></div>					</div>
				</div>
			</div>
		</div>
		

		<div class="copyright-bar">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-sm-7 text-center">
						<p>
						Copyright © 2020 tijarah All Rights Reserved.						</p>
					</div>
				</div>
			</div>
		</div>
	</footer>

	<!--======= Back to Top =======-->
	<div id="backtotop"><i class="fa fa-lg fa-arrow-up"></i></div>

  <script type="text/javascript">
  function search_data_fetch(){
    jQuery.ajax({
        url: 'https://themedox.com/wp-admin/admin-ajax.php',
        type: 'post',
        data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
        success: function(data) {
          if (jQuery('#keyword').val().length !== 0) {
            jQuery('#datafetch').html( data );
          } else {
            jQuery('#datafetch').html( '' );
          }
            
        }
    });

    jQuery("#datafetch").show();
  }
  </script>
	<script type='text/javascript'>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='wc-blocks-style-css' href='https://themedox.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-8.9.2' type='text/css' media='all' />
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/themedox.com\/index.php\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/tijarah-element/inc/../assets/js/plugins.js?ver=1.3.7" id="tijarah-plugins-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/tijarah-element/inc/../assets/js/plugin.js?ver=1.3.7" id="tijarah-plugin-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=8.9.2" id="sourcebuster-js-js"></script>
<script type="text/javascript" id="wc-order-attribution-js-extra">
/* <![CDATA[ */
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"ajaxurl":"https:\/\/themedox.com\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=8.9.2" id="wc-order-attribution-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/popper.min.js?ver=1.3.7" id="popper-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/bootstrap.min.js?ver=1.3.7" id="bootstrap-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/jquery.nice-select.min.js?ver=1.3.7" id="nice-select-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/plyr.min.js?ver=1.3.7" id="plyr-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/audio-player.js?ver=1.3.7" id="tijarah-audio-player-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/jquery.magnific-popup.min.js?ver=1.3.7" id="magnific-popup-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/skip-link-focus-fix.js?ver=1.3.7" id="tijarah-skip-link-focus-fix-js"></script>
<script type="text/javascript" src="https://themedox.com/wp-content/themes/tijarah/assets/js/main.js?ver=1.3.7" id="tijarah-main-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_6772fbb3dac791a3d4c1a546979014aa","fragment_name":"wc_fragments_6772fbb3dac791a3d4c1a546979014aa","request_timeout":"5000"};
/* ]]> */
</script>
<script type="text/javascript" src="https://themedox.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=8.9.2" id="wc-cart-fragments-js" defer="defer" data-wp-strategy="defer"></script>

</body>
</html>


<!-- Page cached by LiteSpeed Cache 6.2.0.1 on 2024-06-08 08:50:33 -->